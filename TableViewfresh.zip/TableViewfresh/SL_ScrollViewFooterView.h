//
//  SL_ScrollViewFooterView.h
//  Sinlang
//
//  Created by zhoumeineng on 16/8/4.
//  Copyright © 2016年 zhoumeineng. All rights reserved.
//


#import "SLScrollViewBase.h"


@interface SL_ScrollViewFooterView : SLScrollViewBase

typedef NS_ENUM(NSInteger) {
    SL_PreIncrease_YES,
    SL_PreIncrease_NO,
}SL_PreIncreaseState;
/**
 初始化
 */
+(SL_ScrollViewFooterView*)SL_FOOTER;

/**
 触发事件
 */
@property(nonatomic,assign)SEL action;

/**
 是否提前加载
 */
@property(nonatomic,assign)SL_PreIncreaseState PreIncreaseState;


@end