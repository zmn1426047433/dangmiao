//
//  UIScrollView+SLScrollViewfresh.h
//  Sinlang
//
//  Created by zhoumeineng on 16/8/4.
//  Copyright © 2016年 zhoumeineng. All rights reserved.
//
/**
 对于 不同方式要用同一个类型里面的方法
 */



#import <UIKit/UIKit.h>

@interface UIScrollView (SLScrollViewfresh)

/**
 上拉加载 objec 为监听的对象
 */
-(void)addfooterfreshTager:(SEL)action object:(id)object;

/**
 上拉加载结束
 */
-(void)endFooterfresh;



/**
 下拉刷新  objec 为监听的对象
 */
-(void)addheaderfreshTager:(SEL)action object:(id)object;

/**
 下拉刷新结束
 */
-(void)endHeaderfresh;


/**
 预加载
 */
-(void)beformefromeData:(SEL)action object:(id)object;

/**
 预加载结束后
 succeed 预加载是否成功
 */
-(void)beformefromeDataEnd:(BOOL)succeed;


@end
