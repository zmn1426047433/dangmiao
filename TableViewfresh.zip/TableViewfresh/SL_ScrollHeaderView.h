//
//  SL_ScrollHeaderView.h
//  Sinlang
//
//  Created by zhoumeineng on 16/8/4.
//  Copyright © 2016年 zhoumeineng. All rights reserved.
//

#import "SLScrollViewBase.h"

@interface SL_ScrollHeaderView : SLScrollViewBase
/**
 初始化
 */
+(instancetype)SL_ScrollHeader;

/**
 tager事件
 */
@property(nonatomic,assign)SEL action;



@end
