//
//  SL_ScrolViewDraw.m
//  Sinlang
//
//  Created by zhoumeineng on 16/8/4.
//  Copyright © 2016年 zhoumeineng. All rights reserved.
//

#import "SL_ScrolViewDraw.h"
@interface SL_ScrolViewDraw()
{
    CAShapeLayer * sha ;
    CGFloat StartAngle;
}
@end
@implementation SL_ScrolViewDraw
- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        StartAngle = 0;
        self.backgroundColor = [UIColor clearColor];
        sha = [CAShapeLayer layer];
        sha.frame = CGRectMake(0, 0, self.bounds.size.width, self.bounds.size.height);
        [self.layer addSublayer:sha];
        sha.actions = @{@"position":[NSNull null],@"bounds":[NSNull null],@"path":[NSNull null]};
        sha.fillColor = [UIColor clearColor].CGColor;
        sha.strokeColor = [UIColor redColor].CGColor;
        sha.backgroundColor = [UIColor whiteColor].CGColor;
    }
    return self;
}



-(CGPathRef)DrawBash:(CGFloat)scal
{
    
    sha.path = nil;
    UIBezierPath *bas = [UIBezierPath bezierPath];

//    bas.lineCapStyle = kCGLineCapButt;
    if (StartAngle<M_PI*2*scal) {
        [bas addArcWithCenter:CGPointMake(30, 30) radius:30 startAngle:0 endAngle:M_PI*2*scal clockwise:NO];
    
    }else{
    [bas addArcWithCenter:CGPointMake(30,30) radius:30 startAngle:0 endAngle:-(M_PI*2- M_PI*2*scal) clockwise:NO];
    }
    bas.lineCapStyle = kCGLineCapRound; //线条拐角
    bas.lineJoinStyle = kCGLineCapSquare; //终点处理
    StartAngle = M_PI*2*scal;
    return bas.CGPath;
}

- (void)DrawCircle:(CGFloat)scarl
{
    [UIView animateWithDuration:0.3 animations:^{
      sha.path = [self DrawBash:scarl];
    }];
}
@end
