//
//  UIScrollView+SLScrollViewfresh.m
//  Sinlang
//
//  Created by zhoumeineng on 16/8/4.
//  Copyright © 2016年 zhoumeineng. All rights reserved.
//



#import "UIScrollView+SLScrollViewfresh.h"
#import "SL_ScrollHeaderView.h"
#import "SL_ScrollViewFooterView.h"
#import <objc/message.h>
@interface UIScrollView()

@property(nonatomic,strong)SL_ScrollHeaderView *header;

@property(nonatomic,strong)SL_ScrollViewFooterView *footer;

@end

@implementation UIScrollView (SLScrollViewfresh)


/**
 关联 header
 */
- (void)setHeader:(SL_ScrollHeaderView *)header
{
    objc_setAssociatedObject(self, @"header", header, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (SL_ScrollHeaderView *)header
{
   return  objc_getAssociatedObject(self, @"header");
}


- (void)addheaderfreshTager:(SEL)action object:(id)object
{
    self.header = [SL_ScrollHeaderView SL_ScrollHeader];
    self.header.action = action;
    self.header.SlObject = object;
    self.header.PrePageSize = 5;
    [self addSubview:self.header];
}



- (void)endHeaderfresh{
    
    ((void(*)(id,SEL,id))objc_msgSend)(self.header,NSSelectorFromString(@"endHeader"),nil);
}


/**
 footer
 */
-(void)setFooter:(SL_ScrollViewFooterView *)footer
{
    objc_setAssociatedObject(self, @"footer", footer, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}


- (SL_ScrollViewFooterView *)footer{
    return objc_getAssociatedObject(self, @"footer");
}


- (void)addfooterfreshTager:(SEL)action object:(id)object
{
    self.footer = [SL_ScrollViewFooterView SL_FOOTER];
    self.footer.action = action;
    self.footer.SlObject = object;
    self.footer.PreIncreaseState = SL_PreIncrease_NO;
    [self addSubview:self.footer];
}

-(void)endFooterfresh
{
((void(*)(id,SEL,id))objc_msgSend)(self.footer,NSSelectorFromString(@"endfooter"),nil);
}

/**
 预加载
 */
-(void)beformefromeData:(SEL)action object:(id)object
{
    self.footer = [SL_ScrollViewFooterView SL_FOOTER];
    self.footer.action = action;
    self.footer.SlObject = object;
    self.footer.PreIncreaseState = SL_PreIncrease_YES;
    self.footer.PrePageSize = 5;
    self.footer.PreIncreaseDataState = SL_PreIncreaseDataState_pre;
    [self addSubview:self.footer];
}
-(void)beformefromeDataEnd:(BOOL)succeed
{
    ((void(*)(id,SEL,BOOL))objc_msgSend)(self.footer,NSSelectorFromString(@"beformefromeDataEnd:"),succeed);
}
@end
