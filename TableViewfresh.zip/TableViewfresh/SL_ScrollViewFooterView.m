//
//  SL_ScrollViewFooterView.m
//  Sinlang
//
//  Created by zhoumeineng on 16/8/4.
//  Copyright © 2016年 zhoumeineng. All rights reserved.
//

#import "SL_ScrollViewFooterView.h"
#import <objc/message.h>

@implementation SL_ScrollViewFooterView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor colorWithRed:0.8 green:0.8 blue:0.8 alpha:1];
        
        self.state = preFreshState;
        
        [self sl_intreose];
    }
    return self;
}

+(SL_ScrollViewFooterView *)SL_FOOTER
{
    return [[SL_ScrollViewFooterView alloc]initWithFrame:CGRectMake(0, 0, AppWight, 0)];
}


- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSString *,id> *)change context:(void *)context
{
    self.SLScroll = object;
    self.frame = CGRectMake(0, self.SLScroll.contentSize.height, AppWight, 60);
   
    if (self.PreIncreaseState == SL_PreIncrease_NO) {
        if (self.SLScroll.contentOffset.y>=self.SLScroll.contentSize.height+60-self.SLScroll.bounds.size.height) {
            self.SLScroll.contentInset = UIEdgeInsetsMake(0, 0, 60, 0);
            if (self.state!=freshingState) {
                [self FooterAction];
                self.SL_introtuce.text = @"正在加载中";
                self.state = freshingState;
            }
        }else{
            self.state = preFreshState;
            self.SL_introtuce.text = @"上拉加载";
            
        }
    }else{
    /**
      提前加载
     */
        if (self.SLScroll.contentOffset.y>=self.SLScroll.contentSize.height/4*3){
            if (self.PreIncreaseDataState !=SL_PreIncreaseDataState_Ing) {
                self.PreIncreaseDataState = SL_PreIncreaseDataState_Ing;
               ((void(*)(id,SEL,id))objc_msgSend)(self.SlObject,self.action,nil);
            }
        }else{
        self.PreIncreaseDataState = SL_PreIncreaseDataState_pre;
        }

    }
    
    
}

-(void)FooterAction
{
    ((void(*)(id ,SEL,id))objc_msgSend)(self.SlObject,self.action,nil);
}

-(void)endfooter
{
    self.SLScroll.contentInset = UIEdgeInsetsMake(0, 0, 0, 0);
    self.state = feshdidState;
}
/**
 上拉加载说明
 */
-(void)sl_intreose
{
    if (!self.SL_introtuce) {
        self.SL_introtuce = [[UILabel alloc]initWithFrame:CGRectMake(0, 10, 100, 30)];
        self.SL_introtuce.center = CGPointMake(self.center.x, self.SL_introtuce.center.y);
        self.SL_introtuce.font = [UIFont systemFontOfSize:15];
        self.SL_introtuce.textColor = [UIColor colorWithRed:0.6 green:0.6 blue:0.6 alpha:1];
        [self addSubview:self.SL_introtuce];
    }
}
/**
 预加载
 */

-(void)beformefromeDataEnd:(BOOL)succeed
{
    if (succeed) {
     self.PrePageSize = self.PrePageSize*2;
    }
    self.PreIncreaseDataState = SL_PreIncreaseDataState_end;
}

@end
