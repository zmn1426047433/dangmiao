//
//  SL_ScrollHeaderView.m
//  Sinlang
//
//  Created by zhoumeineng on 16/8/4.
//  Copyright © 2016年 zhoumeineng. All rights reserved.
//

#import "SL_ScrollHeaderView.h"
#import "SL_ScrolViewDraw.h"
#import <objc/message.h>

@interface DateCode : NSObject<NSCoding>
@property(nonatomic,copy)NSString * Time;
@end
@implementation DateCode

- (void)encodeWithCoder:(NSCoder *)aCoder
{
    [aCoder encodeObject:self.Time forKey:@"SL_TIME"];
}

- (instancetype)initWithCoder:(NSCoder *)aDecoder
{
    self.Time = [aDecoder decodeObjectForKey:@"SL_TIME"];
    return self;
}
@end


@interface SL_ScrollHeaderView()
@property(nonatomic,strong)SL_ScrolViewDraw *sl_draw;
@end
@implementation SL_ScrollHeaderView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor colorWithRed:0.9 green:0.9 blue:0.9 alpha:1];
        //默认刷新前
        self.state = preFreshState;
        
        //画图
      //  [self sl_draw];
        
        /**
         时间
         */
        [self TimeLable];
        
        /**
         刷新说明
         */
        [self SL_instrotue];
        
        
        /**
         路径
         */
        [self GETPathSeachLibary];
        
        
    }
    return self;
}

+(instancetype)SL_ScrollHeader
{
    return [[SL_ScrollHeaderView alloc]initWithFrame:CGRectMake(0, -60, AppWight, 60)];
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSString *,id> *)change context:(void *)context
{
   self.SLScroll = object;
    self.SLScroll.backgroundColor = self.backgroundColor;
    if (self.SLScroll.contentOffset.y<=-60) {
        [self.sl_draw removeFromSuperview];
        _sl_draw = nil;
        [self.SLScroll setContentInset:UIEdgeInsetsMake(60, 0, 0, 0)];
        if (self.state !=freshingState) {
          [self headerfreshAction];
         self.state =freshingState;
        [self SL_NSdocedDate:[self SL_Now_Date] filepatch:[self GETPathSeachLibary]];
        self.SL_introtuce.text = @"Z-周哥-Z 正在刷新";
        }
    }else if(self.SLScroll.contentOffset.y<0){
        /**
         画图暂时不需要
         */
//    [self.sl_draw DrawCircle:fabs(self.SLScroll.contentOffset.y/60.0)];
        self.SL_time.text = [self dateString:[self SL_Getdate:[self GETPathSeachLibary]]];
        self.SL_introtuce.text = @"Z-周哥-Z 下拉刷新";
    }
}
- (SL_ScrolViewDraw *)sl_draw
{
    if (!_sl_draw) {
        _sl_draw = [[SL_ScrolViewDraw alloc]initWithFrame:CGRectMake(60, 0, 60, 60)];
        [self addSubview:_sl_draw];
    }
    return _sl_draw;
}
/**
 刷新结束
 */
-(void)endHeader
{
    self.state = feshdidState;
    [UIView animateWithDuration:0.9 animations:^{
      [self.SLScroll setContentInset:UIEdgeInsetsMake(0, 0, 0, 0)];
    }];
}

/**
 刷新时事件触发
 */
- (void)headerfreshAction
{
  ((void(*)(id,SEL,id))objc_msgSend)(self.SlObject,self.action,nil);
}

/**
 刷新说明
 */
-(void)SL_instrotue
{
    if (!self.SL_introtuce) {
        self.SL_introtuce = [[UILabel alloc]initWithFrame:CGRectMake(self.bounds.size.width/2 - 40, 20, 200, 20)];
        self.SL_introtuce.textColor = self.SL_time.textColor;
        self.SL_introtuce.font = self.SL_time.font;
        self.SL_introtuce.shadowColor = [UIColor blackColor];
        self.SL_introtuce.shadowOffset = CGSizeMake(2, 2);
        [self addSubview:self.SL_introtuce];
    }
}



/**
 属性生成
 */

-(void)TimeLable
{
    if (!self.SL_time) {
        self.SL_time = [[UILabel alloc]initWithFrame:CGRectMake(self.bounds.size.width/2 - 40, self.bounds.size.height-20, 200, 20)];
        self.SL_time.textColor = [UIColor colorWithRed:0.6 green:0.6 blue:0.6 alpha:1];
        self.SL_time.font = [UIFont systemFontOfSize:15];
        [self addSubview:self.SL_time];
    }
  
}


/**
 c存档
 */
-(void)SL_NSdocedDate:(NSString*)date filepatch:(NSString*)file
{
    DateCode * code = [[DateCode alloc]init];
    code.Time = date;
    if ([NSKeyedArchiver archiveRootObject:code toFile:file]) {
    }
    code = nil;
}

/**
 解档
 */
-(NSString*)SL_Getdate:(NSString*)file
{
  DateCode * code = [NSKeyedUnarchiver unarchiveObjectWithFile:file];
    if (code) {
      return code.Time;
    }
  return @"";
}

/**
 时间生成
 */
-(NSString *)SL_Now_Date{
    NSDate * date = [NSDate date];
    NSDateFormatter * fomater = [[NSDateFormatter alloc]init];
    [fomater setDateFormat:@"yyyy:MM:dd HH:mm"];
    return  [fomater stringFromDate:date];
}

/**
 时间比较
 */

-(NSString*)dateString:(NSString*)date
{
    NSDate *Nowdate = [NSDate date];
    NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
    [formatter setDateFormat:@"yyyy:MM:dd HH:mm"];
    NSDate *old = [formatter dateFromString:date];
    NSTimeInterval time = [Nowdate timeIntervalSinceDate:old];
    
    if (fabs(time)/60/24<1) {
        
        return [NSString stringWithFormat:@"今天：%@",[date substringWithRange:NSMakeRange(date.length-5, 5)]];
    }
    return date;
    
}

/**
 存储文件的地址
 */
-(NSString*)GETPathSeachLibary
{
  NSFileManager * filemanager = [NSFileManager defaultManager];
    
  NSString * path  =  NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES).lastObject;
    NSString * filestring = [path stringByAppendingFormat:@"/SCrollDate"];
    if (![filemanager isExecutableFileAtPath:filestring]) {
        [filemanager createDirectoryAtPath:filestring withIntermediateDirectories:YES attributes:nil error:nil];
    }

    NSString * filepath = [filestring stringByAppendingString:@"/Date.plist"];
    if (![filemanager fileExistsAtPath:filepath]) {
        [filemanager createFileAtPath:filepath contents:nil attributes:nil];
    }
  
    return filepath;
}

@end
