//
//  SLScrollViewBase.m
//  Sinlang
//
//  Created by zhoumeineng on 16/8/4.
//  Copyright © 2016年 zhoumeineng. All rights reserved.
//

#import "SLScrollViewBase.h"
@interface SLScrollViewBase()<UIScrollViewDelegate>
@end
@implementation SLScrollViewBase

- (void)willMoveToSuperview:(UIView *)newSuperview
{
    [super willMoveToSuperview:newSuperview];
    [self.superview removeObserver:self forKeyPath:@"contentOffset"];
    if (newSuperview) {
   // newSuperview 被监听  self 为监听者
      [newSuperview addObserver:self forKeyPath:@"contentOffset" options:NSKeyValueObservingOptionNew context:nil];
    }
}


+(instancetype)header
{
    return [[[self class] alloc] init];
}


@end
