//
//  SL_ScrolViewDraw.h
//  Sinlang
//
//  Created by zhoumeineng on 16/8/4.
//  Copyright © 2016年 zhoumeineng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SL_ScrolViewDraw : UIView
/**
  DrawCircl To animal
 */
-(void)DrawCircle:(CGFloat)scarl;
@end
