//
//  SLScrollViewBase.h
//  Sinlang
//
//  Created by zhoumeineng on 16/8/4.
//  Copyright © 2016年 zhoumeineng. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger) {

    freshingState,//真在刷新
    feshdidState,//刷新后
    preFreshState,//刷新前
}freshState;


typedef NS_ENUM(NSInteger){
    SL_PreIncreaseDataState_pre,//预加载前
    SL_PreIncreaseDataState_Ing,//预加载中
    SL_PreIncreaseDataState_end,//预加载后
}SL_PreIncreaseDataState;



@interface SLScrollViewBase : UIView

+(instancetype)header;

@property(nonatomic,strong)UIScrollView * SLScroll;


/**
 刷新状态
 */
@property(nonatomic,assign)freshState state;

/**
 发送方法的对象
 */
@property(nonatomic,strong)NSObject * SlObject;

/**
 imageView
 */
@property(nonatomic,strong)UIImageView *AnimalImageView;

/**
 Timelable
 */
@property(nonatomic,strong)UILabel * SL_time;


/**
 introtuce
 */
@property(nonatomic,strong)UILabel * SL_introtuce;


/**
 预加载提前多少开始加载
 */
@property(nonatomic,assign)int PrePageSize;

/**
 预加载状态
 */
@property(nonatomic,assign)SL_PreIncreaseDataState PreIncreaseDataState;

@end
